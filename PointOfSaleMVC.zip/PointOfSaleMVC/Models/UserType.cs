﻿namespace PointOfSaleMVC.Models
{
    public class UserType
    {
        public int UserTypeId { get; set; }
        public string Type { get; set; }
    }
}